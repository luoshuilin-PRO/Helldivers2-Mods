RL-77 原版与TD-220主炮弹菜单 v0.1.1 实验版
只保留两项：原版特殊弹（集束，默认）／TD-220堡垒主炮弹。
普通防空模式保持原版；未修改伤害、射速、弹药及供体数据。
新版使用新菜单保存键，避免旧版弹种索引误选。资源名称与GUID保持原版系列一致。
风暴漩涡slot_3/slot_4为生成导弹实体，不能作为当前function_ammo.projectile接口供体，因此不添加右键导弹。不能把slot_2冒充右键导弹。
完全退出游戏，停用RL-77-Special-Ammo-Menu-v0.1.0及其他RL-77弹药mod。
导入本包并启用；依赖Loader v18、HD2Runtime0.28.1 / API1、Mod Options Menu API1。Loader底部，Purge → Deploy。
ESC → MODS → RL-77 原版与坦克弹，选择并APPLY，然后重新呼叫RL-77。
长按换弹键，选择原生特殊/集束模式才发射所选炮弹。恢复原版选择第一项。
TD-220选项发射实际主炮弹丸，使用其弹道与爆炸，不保证继续空爆/分裂；不会赋予坦克的其他火控功能。
Runtime应用时加载供体资源，首次可能等待。其他客户端表现不保证一致。
本包尚未游戏内验证，保留身份、资源和冲突检查。只本地生成，没有上传GitHub。
依据 https://github.com/SkyeShade/HD2Runtime/blob/master/sdk/AttackOutputCapabilities.json
