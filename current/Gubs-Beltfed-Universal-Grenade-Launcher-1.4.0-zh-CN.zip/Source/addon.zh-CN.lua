-- HD2-Addon: mods/bfgl_rounds/bfgl_grenade_rounds
local loader=rawget(_G,'CowboyBingusModLoader')
assert(loader and loader.api==1 and type(loader.version)=='number' and loader.version>=16,
    'Requires Bingus Shared Loader v15+ / API 1')
local hd2=require('mods/skyeshade/hd2runtime')
local function semver(v)
    local core,pre=tostring(v):match('^([^%-+]+)%-?([^+]*)')
    local a,b,c=(core or''):match('^(%d+)%.(%d+)%.(%d+)$')
    assert(a,'Invalid HD2Runtime version: '..tostring(v))
    local ids={}
    for id in(pre~=''and pre..'.'or''):gmatch('([^%.]*)%.')do ids[#ids+1]=id end
    return {tonumber(a),tonumber(b),tonumber(c),ids}
end
local function order(p,q)
    local x,y=tonumber(p:match('^%d+$')),tonumber(q:match('^%d+$'))
    if x and y then return x<y and -1 or x>y and 1 or 0 end
    if x then return -1 end
    if y then return 1 end
    return p<q and -1 or p>q and 1 or 0
end
local function at_least(have,need)
    local x,y=semver(have),semver(need)
    for i=1,3 do if x[i]~=y[i]then return x[i]>y[i]end end
    local p,q=x[4],y[4]
    if#p==0 then return true end
    if#q==0 then return false end
    for i=1,math.max(#p,#q)do
        if p[i]==nil then return false end
        if q[i]==nil then return true end
        local o=order(p[i],q[i])
        if o~=0 then return o>0 end
    end
    return true
end
local minimum="0.28.0"
local satisfied=hd2.api_version==1 and at_least(hd2.version,minimum)
if not satisfied and hd2.api_version==1 then
    local compatibility=type(hd2.compatibility)=='table'and hd2.compatibility.require_runtime
    if type(compatibility)=='function'then pcall(compatibility,"mods/bfgl_rounds/bfgl_grenade_rounds",minimum,"GL-28 万能榴弹发射器")end
end
assert(satisfied,'HD2Runtime dependency version mismatch')
local key='HD2RuntimeMod:'.."mods/bfgl_rounds/bfgl_grenade_rounds"
local existing=rawget(_G,key)
if existing then return existing end
local function start()
local hd2=require('mods/skyeshade/hd2runtime')
-- GL-28 万能榴弹发射器
-- Two customizable ammo modes for the GL-28 Belt-Fed Grenade Launcher, switched in a mission by holding Reload.
--
-- FIRST ROUND (normal mode): the GL-28's own grenade row takes the chosen round's hit damage and impact blast. It
--   still flies like a BFGL grenade (HD2Runtime cannot swap the GL-28's normal projectile: it is not magazine-fed).
--   Only the GL-28 fires this row, so no other weapon changes.
-- SECOND ROUND (special mode): Speargun Gas / Stun pattern. The game's ProgrammableAmmo weapon function goes on the
--   GL-28's free left weapon-function input and fires the chosen round itself.
--
-- Pick both in Escape > MODS > BFGL Rounds. Page Up / Page Down cycle the second round in a mission.

local mod=hd2.mod()
local gl28=hd2.support_weapon('GL-28 Belt-Fed Grenade Launcher')
local source=gl28:feed('programmable'):source()
assert(source.writable and source.binding,'the GL-28 can no longer take a programmable projectile on this HD2Runtime')
local standard=hd2.attack_output('GL-28 Belt-Fed Grenade Launcher')

-- name, donor output, the handle whose package to preload (nil: loaded on first use), mode label,
-- and which donor explosion becomes the first round's blast (the EMS field is the shell's expiry explosion).
local ROUNDS={
    {'标准榴弹（原版）',     standard,                                        nil,                                         'standard'},
    {'燃烧弹（EAT-700）',       'EAT-700 Expendable Napalm',                     hd2.support_weapon('EAT-700 Expendable Napalm'), 'incendiary'},
    {'最后通牒（GP-20）',    'GP-20 Ultimatum',                               hd2.weapon('GP-20 Ultimatum'),               'he_mk2'},
    {'电弧弹（GL-52）', 'GL-52 De-Escalator',                            hd2.support_weapon('GL-52 De-Escalator'),    'arc'},
    {'重型爆破弹（EAT-411）',     'EAT-411 Leveller',                              hd2.support_weapon('EAT-411 Leveller'),      'heat_mk2'},
    {'电磁静滞弹（EMS）',    'A/M-23 EMS Mortar Sentry',                      nil,                                         'stun', 'expiry'},
    {'类星体炮弹（LAS-99）',       'LAS-99 Quasar Cannon',                          hd2.support_weapon('LAS-99 Quasar Cannon'),  'heat'},
    {'等离子弹（PLAS-1）',  'PLAS-1 Scorcher',                               hd2.weapon('PLAS-1 Scorcher'),               'he'},
    {'机甲自动炮弹（EXO-49）',  'EXO-49 Emancipator Exosuit / left_gun',         hd2.vehicle('EXO-49 Emancipator Exosuit'),   'aphet'},
}
local DEFAULT_FIRST,DEFAULT_SECOND=4,5 -- De-Escalator / Leveller (indices into ROUNDS)

local names,outputs,hits,blasts,labels,preload={},{},{},{},{},{}
for i,r in ipairs(ROUNDS)do
    local output=type(r[2])=='string'and hd2.attack_output(r[2])or r[2]
    names[i],outputs[i],labels[i]=r[1],output,r[4]
    hits[i]=output:direct_damage()
    blasts[i]=r[5]=='expiry'and output:expiry_explosion()or output:impact_explosion()
    if r[3]then preload[#preload+1]=r[3]end
end

-- Faster switching: load every donor's assets once at startup, so a later switch never waits for a package.
-- (The EMS shell's package is a stratagem's and can only be loaded by its first use.)
pcall(hd2.require_assets,{id='bfgl-preload',targets=preload})

-- MODS menu: just the two rounds.
local options=hd2.options({id='bfgl_rounds',title="GL-28 万能榴弹发射器"})
local first=options:choice({id='first',label='第一种弹药（普通模式）',choices=names,values=blasts,default=DEFAULT_FIRST,
    description='普通模式：保持GL-28榴弹弹道，使用所选弹药的直击与爆炸效果。标准榴弹为原版。'})
local specialNames,specialValues={},{}
for i=2,#ROUNDS do specialNames[i-1]=names[i];specialValues[i-1]=outputs[i]end
local second=options:choice({id='special',label='第二种弹药（特殊模式）',choices=specialNames,values=specialValues,
    default=DEFAULT_SECOND-1,description='特殊模式：直接发射所选弹丸。长按换弹键切换模式；Page Up / Page Down循环选择第二种弹药。'})

-- The first round's hit damage and menu label follow First round. They are script-driven choices that never appear
-- in the menu (script values converted to choices over the same rounds).
local function follower(id,values)
    local handle=mod:value({id=id,min=1,max=#ROUNDS,step=1,default=DEFAULT_FIRST})
    handle.kind,handle.choices,handle.values,handle.default,handle.selected=
        'choice',names,values,DEFAULT_FIRST,DEFAULT_FIRST
    return handle
end
local firstHit=follower('first_hit',hits)
local firstLabel=follower('first_label',labels)
local function sync(handle)
    local index=handle:index()
    if index then firstHit:assign(index,'script');firstLabel:assign(index,'script')end
end
first:subscribe(sync)
sync(first)

local operations={}
local function ensure(transaction)operations[#operations+1]=hd2.ensure({transaction=transaction})end

-- Second round: the selector and the special projectile, written together.
ensure({id='bfgl-mode',target=source.target,allow_unverified_effect=true,allow_unverified_reference=true,changes={
    {field=source.binding.field,expect=source.binding.expect,value=source.binding.value},
    {field=hd2.fields.function_ammo.projectile,expect=source.expect,value=second}}})

-- First round: the GL-28's own grenade row takes the chosen round's hit damage and impact blast.
ensure({id='bfgl-first',target=standard,allow_unverified_effect=true,changes={
    {field=hd2.fields.projectile.direct_damage,expect=standard:direct_damage(),value=firstHit},
    {field=hd2.fields.projectile.impact_explosion,expect=standard:impact_explosion(),value=first}}})

-- Weapon-function menu labels: the normal mode shows the GL-28 row's label, the special mode the donor row's.
for i,output in ipairs(outputs)do
    local current=output:describe().presentation
    ensure({id='bfgl-label-'..i,target=output,allow_unverified_effect=true,allow_shared=current.shared==true or nil,
        changes={
            {field=hd2.fields.presentation.mode_label,expect=current.label,value=i==1 and firstLabel or labels[i]},
            {field=hd2.fields.presentation.mode_icon,expect=current.icon,value='auto'}}})
end

-- Page Up / Page Down: cycle the second round.
local function step(delta)
    local index=(second:index()or 1)-1
    second:assign((index+delta)%#specialNames+1,'script')
end
mod:bind('bfgl_rounds.next',{key='PAGEUP',on_press=function()step(1)end})
mod:bind('bfgl_rounds.previous',{key='PAGEDOWN',on_press=function()step(-1)end})

return operations

end
local run=type(hd2.events)=='table' and hd2.events.run_as
local state
if type(run)=='function' then state=run("mods/bfgl_rounds/bfgl_grenade_rounds",start) else state=start() end
state=state or true
rawset(_G,key,state)
return state
