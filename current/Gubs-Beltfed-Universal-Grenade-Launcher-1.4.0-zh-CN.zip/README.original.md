# Gub's Beltfed Universal Grenade Launcher

Gives the **GL-28 Belt-Fed Grenade Launcher** two customizable ammo modes. Hold **Reload** in a mission to switch.

| Mode | How it works |
| --- | --- |
| First round (normal mode) | The BFGL grenade keeps its own flight, but hits and explodes like the chosen round |
| Second round (special mode) | Fires the chosen round itself (same method as the Speargun Gas / Stun mod) |

Rounds: Standard (vanilla BFGL, first round only), Napalm (EAT-700), Ultimatum (GP-20), De-Escalator (GL-52),
Leveller (EAT-411), EMS Shell (A/M-23, leaves a stun field), Quasar (LAS-99), Plasma Bolt (PLAS-1 Scorcher),
Emancipator (EXO-49 cannon).

Default: **De-Escalator / Leveller**.

## Requirements
- Bingus Shared Loader v15+ (v18+ if you also use Mod Options Menu)
- HD2Runtime 0.28.0+ (separate download, must be enabled)
- Mod Options Menu (recommended: needed to pick rounds other than the defaults)

## Install (Arsenal)
1. Close the game.
2. Import Bingus Shared Loader, HD2Runtime and this ZIP. Enable all three.
3. Put Bingus Shared Loader **last** in the load order.
4. Purge, then Deploy.

## Use
- Escape > MODS > Gub's Beltfed Universal Grenade Launcher: set **First round** and **Second round**, press APPLY.
- Call in a **fresh** GL-28 after changing anything.
- Hold **Reload** to switch between the two modes.
- **Page Up / Page Down** cycle the second round.

## Warning
Leveller and Ultimatum blasts are huge. On the first round they keep the BFGL's fire rate. Don't shoot close.

## If nothing shows up
Check `%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\HD2Runtime.log` for `bfgl-mode` and `bfgl-first`
(APPLIED, or the refusal reason).
