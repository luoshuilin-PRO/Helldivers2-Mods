-- HD2-Addon: mods/luoshuilin/frv_exo49_sliders
-- v0.1.1: Loader Lua ABI version is separate from its release label.
-- v0.1.1: Loader Lua ABI version is separate from its release label.
-- Original preset is the default. No raw addresses or guessed damage owners.
local loader=rawget(_G,'CowboyBingusModLoader')
assert(loader and loader.api==1 and type(loader.version)=='number' and loader.version>=16,
    'Requires Bingus Shared Loader v18 / API 1')
local runtime=require('mods/skyeshade/hd2runtime')
local minimum='0.28.1'
local function at_least(current,required)
    local a,b,c=tostring(current):match('^(%d+)%.(%d+)%.(%d+)')
    local x,y,z=required:match('^(%d+)%.(%d+)%.(%d+)$')
    if not a then return false end
    a,b,c,x,y,z=tonumber(a),tonumber(b),tonumber(c),tonumber(x),tonumber(y),tonumber(z)
    return a>x or a==x and (b>y or b==y and c>=z)
end
assert(runtime.api_version==1 and at_least(runtime.version,minimum),
    'Requires HD2Runtime 0.28.1 / API 1')
local key='HD2RuntimeMod:mods/luoshuilin/frv_exo49_sliders'
local existing=rawget(_G,key)
if existing then return existing end
local function start()
    local hd2=runtime
    local mod=hd2.mod()
    local state={watches={},menu_registered=false}
    local frv=hd2.vehicle('M-102 Gunner FRV'):weapon('gun')
    local donor=hd2.vehicle('EXO-49 Emancipator Exosuit'):weapon('left_gun')
    local source=frv:projectile_source()
    state.watches[#state.watches+1]=hd2.ensure({patch={id='frv-projectile',target=source.target,field=source.field,expect=source.expect,value=donor:attack('primary'),allow_shared=true,allow_unverified_effect=true,allow_unverified_reference=true}})
    local gun=frv
    local projectile=donor:projectile()
    local explosion=donor:explosion('impact')
    local rate=mod:value({id='rate',min=600,max=900,step=5,default=600})
    local capacity=mod:value({id='capacity',min=100,max=1000,step=10,default=100})
    local spare=mod:value({id='spare',min=4,max=24,step=1,default=4})
    local damage=mod:value({id='damage',min=300,max=4500,step=50,default=300})
    local durable=mod:value({id='durable',min=150,max=4500,step=50,default=150})
    local ap=mod:value({id='ap',min=5,max=7,step=1,default=5})
    local blast=mod:value({id='blast',min=150,max=2000,step=50,default=150})
    local blastdur=mod:value({id='blastdur',min=150,max=2000,step=50,default=150})
    local blastap=mod:value({id='blastap',min=3,max=7,step=1,default=3})
    local outer=mod:value({id='outer',min=4.5,max=12,step=0.5,default=4.5})
    local shock=mod:value({id='shock',min=6,max=16,step=0.5,default=6})
    state.watches[#state.watches+1]=hd2.ensure({plan={id='frv-tuning',operations={
      {id='gun_weapon',target=gun,allow_shared=true,allow_unverified_effect=true,changes={{field=hd2.fields.weapon.fire_rate,expect=600,value=rate},{field=hd2.fields.weapon.capacity,expect=100,value=capacity}}},
      {id='gun_magazine',target=gun,allow_shared=true,allow_unverified_effect=true,changes={{field=hd2.fields.magazine.spare_magazines,expect=4,value=spare}}},
      {id='damage',target=projectile,allow_shared=true,allow_unverified_effect=true,changes={{field=hd2.fields.damage.player_standard_damage,expect=300,value=damage},{field=hd2.fields.damage.player_durable_damage,expect=150,value=durable},{field=hd2.fields.damage.ap_direct,expect=5,value=ap},{field=hd2.fields.damage.ap_slight,expect=5,value=ap},{field=hd2.fields.damage.ap_large,expect=5,value=ap}}},
      {id='blastdamage',target=explosion,allow_shared=true,allow_unverified_effect=true,changes={{field=hd2.fields.explosion.damage_standard_damage,expect=150,value=blast},{field=hd2.fields.explosion.damage_durable_damage,expect=150,value=blastdur},{field=hd2.fields.explosion.damage_ap_direct,expect=3,value=blastap}}},
      {id='explosion_explosion',target=explosion,allow_shared=true,allow_unverified_effect=true,changes={{field=hd2.fields.explosion.outer_radius,expect=4.5,value=outer},{field=hd2.fields.explosion.shockwave_radius,expect=6,value=shock}}},
    }}})
    local elapsed=0
    local function register_menu()
      if state.menu_registered then return end
      local menu=rawget(_G,'ModOptionsMenu')
      if type(menu)~='table' or menu.api~=1 or type(menu.register_option)~='function' or type(menu.on_change)~='function' or type(menu.get)~='function' then return end
      do
        local id='luoshuilin.frv_exo49_sliders.v1.rate'
        local ok,why=menu.register_option(id,{type='slider',mod='FRV 自动炮弹丸',label='射速（RPM）',min=600,max=900,step=5,default=600,description='最左为当前炮台/弹丸原始值，非原版FRV。APPLY后重新呼叫车辆；实验范围未验证。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n) if type(n)=='number' and n>=600 and n<=900 then rate:set(n) end end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.frv_exo49_sliders.v1.capacity'
        local ok,why=menu.register_option(id,{type='slider',mod='FRV 自动炮弹丸',label='弹匣容量',min=100,max=1000,step=10,default=100,description='最左为当前炮台/弹丸原始值，非原版FRV。APPLY后重新呼叫车辆；实验范围未验证。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n) if type(n)=='number' and n>=100 and n<=1000 then capacity:set(n) end end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.frv_exo49_sliders.v1.spare'
        local ok,why=menu.register_option(id,{type='slider',mod='FRV 自动炮弹丸',label='备用弹匣',min=4,max=24,step=1,default=4,description='最左为当前炮台/弹丸原始值，非原版FRV。APPLY后重新呼叫车辆；实验范围未验证。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n) if type(n)=='number' and n>=4 and n<=24 then spare:set(n) end end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.frv_exo49_sliders.v1.damage'
        local ok,why=menu.register_option(id,{type='slider',mod='FRV 自动炮弹丸',label='直击伤害',min=300,max=4500,step=50,default=300,description='最左为当前炮台/弹丸原始值，非原版FRV。APPLY后重新呼叫车辆；实验范围未验证。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n) if type(n)=='number' and n>=300 and n<=4500 then damage:set(n) end end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.frv_exo49_sliders.v1.durable'
        local ok,why=menu.register_option(id,{type='slider',mod='FRV 自动炮弹丸',label='直击耐久伤害',min=150,max=4500,step=50,default=150,description='最左为当前炮台/弹丸原始值，非原版FRV。APPLY后重新呼叫车辆；实验范围未验证。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n) if type(n)=='number' and n>=150 and n<=4500 then durable:set(n) end end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.frv_exo49_sliders.v1.ap'
        local ok,why=menu.register_option(id,{type='slider',mod='FRV 自动炮弹丸',label='直击穿甲',min=5,max=7,step=1,default=5,description='最左为当前炮台/弹丸原始值，非原版FRV。APPLY后重新呼叫车辆；实验范围未验证。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n) if type(n)=='number' and n>=5 and n<=7 then ap:set(n) end end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.frv_exo49_sliders.v1.blast'
        local ok,why=menu.register_option(id,{type='slider',mod='FRV 自动炮弹丸',label='爆炸伤害',min=150,max=2000,step=50,default=150,description='最左为当前炮台/弹丸原始值，非原版FRV。APPLY后重新呼叫车辆；实验范围未验证。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n) if type(n)=='number' and n>=150 and n<=2000 then blast:set(n) end end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.frv_exo49_sliders.v1.blastdur'
        local ok,why=menu.register_option(id,{type='slider',mod='FRV 自动炮弹丸',label='爆炸耐久伤害',min=150,max=2000,step=50,default=150,description='最左为当前炮台/弹丸原始值，非原版FRV。APPLY后重新呼叫车辆；实验范围未验证。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n) if type(n)=='number' and n>=150 and n<=2000 then blastdur:set(n) end end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.frv_exo49_sliders.v1.blastap'
        local ok,why=menu.register_option(id,{type='slider',mod='FRV 自动炮弹丸',label='爆炸正面穿甲',min=3,max=7,step=1,default=3,description='最左为当前炮台/弹丸原始值，非原版FRV。APPLY后重新呼叫车辆；实验范围未验证。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n) if type(n)=='number' and n>=3 and n<=7 then blastap:set(n) end end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.frv_exo49_sliders.v1.outer'
        local ok,why=menu.register_option(id,{type='slider',mod='FRV 自动炮弹丸',label='爆炸外半径（米）',min=4.5,max=12,step=0.5,default=4.5,description='最左为当前炮台/弹丸原始值，非原版FRV。APPLY后重新呼叫车辆；实验范围未验证。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n) if type(n)=='number' and n>=4.5 and n<=12 then outer:set(n) end end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.frv_exo49_sliders.v1.shock'
        local ok,why=menu.register_option(id,{type='slider',mod='FRV 自动炮弹丸',label='冲击波半径（米）',min=6,max=16,step=0.5,default=6,description='最左为当前炮台/弹丸原始值，非原版FRV。APPLY后重新呼叫车辆；实验范围未验证。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n) if type(n)=='number' and n>=6 and n<=16 then shock:set(n) end end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      state.menu_registered=true;mod:log('SLIDERS_REGISTERED')
    end
    state.menu_timer=mod:every(1,function(timer) elapsed=elapsed+1;register_menu();if state.menu_registered or elapsed>=30 then timer:cancel() end end,{id='menu',scope='session'})
    return state
end
local state=runtime.events.run_as('mods/luoshuilin/frv_exo49_sliders',start)
rawset(_G,key,state)
return state
