# Gub的GL-28万能榴弹发射器 1.4.0 中文版

## 功能
给GL-28弹链式榴弹发射器提供两种可自选弹药模式。
- 第一种（普通模式）：保持原版榴弹的飞行、弧线和手感，使用所选弹药的直击伤害与爆炸效果。
- 第二种（特殊模式）：直接发射所选弹丸，使用它自己的弹道和效果。
默认组合：电弧弹（GL-52）／重型爆破弹（EAT-411）。

## 可选弹药
- 标准榴弹：原版GL-28，仅第一种模式可选。
- 燃烧弹：EAT-700，附带燃烧效果。
- 最后通牒：GP-20重型弹。
- 电弧弹：GL-52。
- 重型爆破弹：EAT-411，爆炸范围巨大。
- 电磁静滞弹：A/M-23 EMS迫击炮弹，产生眩晕场。
- 类星体炮弹：LAS-99。
- 等离子弹：PLAS-1焦土。
- 机甲自动炮弹：EXO-49左臂自动炮。
上述中文名称为便于理解的说明译名；英文原名可参考随附原版说明。

## 依赖与安装
1. 完全退出游戏，停用英文原版；不要同时启用中英文两份。
2. 导入并启用Bingus Shared Loader v15+、HD2Runtime0.28.0+和本ZIP。
3. 推荐安装Mod Options Menu兼容API1版本；使用菜单时Loader需v18+。
4. Loader放加载顺序最底部，Purge → Deploy。
5. 进入任务后呼叫全新的GL-28。
原资源名称、GUID、菜单保存键、默认弹药及功能逻辑保留。

## 操作
- ESC → MODS → GL-28 万能榴弹发射器：选择两种弹药，然后按APPLY应用。
- 长按换弹键：在普通／特殊模式之间切换。
- Page Up / Page Down：循环切换第二种弹药。
- 修改弹药后呼叫新武器，场上旧武器可能保持原设置。
- 不安装菜单时使用默认电弧弹／重型爆破弹组合。

## 原生换弹标签对照
STANDARD：标准；INCENDIARY：燃烧；HE MK2：高爆II；ARC：电弧；HEAT MK2：反坦克II；STUN：眩晕；HEAT：反坦克；HE：高爆；APHET：穿甲高爆曳光。
这些是游戏原生枚举标签，本版保留原标签，未伪造中文枚举。

## 注意与诊断
EAT-411和GP-20爆炸巨大；普通模式仍使用GL-28射速，请保持距离。
原作者说明除EMS弹首次使用加载外，其余弹丸在启动时预加载；只针对GL-28修改，本次汉化没有新增数值改动。
本地修改在多人模式的显示不保证一致。
若不生效，查看 %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\HD2Runtime.log 中 bfgl-mode / bfgl-first 的APPLIED或拒绝原因。
本版仅完成Lua5.1语法编译检查，中文字体、菜单及游戏效果尚未游戏内验证。

## 致谢及AI披露
原模组：Gub's Beltfed Universal Grenade Launcher 1.4.0。
原作者披露使用Claude Opus 5.5（Anthropic）制作。
SkyeShade：HD2Runtime；CowboyBingus：Loader与Mod Options Menu；huffdesigns：鱼叉枪Gas/Stun实现启发。
本次只作中文本地化，未同步GitHub。
