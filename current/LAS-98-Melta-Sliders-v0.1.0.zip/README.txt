LAS-98 熔融光束自由滑条 v0.1.0 实验版
这是独立制作的类似效果版本，不是已删除 Melta Laser Cannon 的恢复文件。
首次默认原版。光束伤害350–3500，耐久伤害200–3000，四种角度穿甲统一AP4–7。
热容量100–400，冷却速度5–40，备用散热器2–8。热生成、光束射程/宽度、视觉效果保持原版。
建议起步：伤害1750，耐久1500，AP6，热容量200，冷却20，备用4。
伤害数值是原生字段值，不保证最终每秒伤害；不保证穿透不可破坏对象或所有敌人。
共享伤害数据可能同时影响激光哨戒炮及关联效果。不要与其他LAS-98/激光哨戒炮伤害mod同时启用。
依赖：Bingus Shared Loader v18 / API1、HD2Runtime0.28.1 / API1、Mod Options Menu v1.1或兼容API1版本。
退出游戏，把本ZIP及依赖导入Arsenal，启用，Loader放最底部，Purge → Deploy。
游戏中ESC → MODS → LAS-98 熔融光束，拉动滑条点击APPLY，再重新呼叫装备。
最左恢复原版；应用后的数值会保存。没有菜单时保留原版。
基准来自HD2Runtime0.28.1 SupportWeaponAuthoringCapabilities.json，针对Steam build25480438。
游戏更新/数据冲突时可能拒绝写入；本包只做Lua语法编译检查，尚未游戏内验证。
SDK：https://github.com/SkyeShade/HD2Runtime
Runtime：https://github.com/SkyeShade/HD2Runtime/releases/download/v0.28.1/HD2Runtime-0.28.1-runtime.zip
