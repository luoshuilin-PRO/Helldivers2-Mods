-- HD2-Addon: mods/luoshuilin/rl77_special_ammo
-- v0.1.1: Only native special ammunition and TD-220 main cannon output.
-- v0.1.1: Only native special ammunition and TD-220 main cannon output.
-- Original preset is the default. No raw addresses or guessed damage owners.
local loader=rawget(_G,'CowboyBingusModLoader')
assert(loader and loader.api==1 and type(loader.version)=='number' and loader.version>=16,
    'Requires Bingus Shared Loader v18 / API 1')
local runtime=require('mods/skyeshade/hd2runtime')
local minimum='0.28.1'
local function at_least(current,required)
    local a,b,c=tostring(current):match('^(%d+)%.(%d+)%.(%d+)')
    local x,y,z=required:match('^(%d+)%.(%d+)%.(%d+)$')
    if not a then return false end
    a,b,c,x,y,z=tonumber(a),tonumber(b),tonumber(c),tonumber(x),tonumber(y),tonumber(z)
    return a>x or a==x and (b>y or b==y and c>=z)
end
assert(runtime.api_version==1 and at_least(runtime.version,minimum),
    'Requires HD2Runtime 0.28.1 / API 1')
local key='HD2RuntimeMod:mods/luoshuilin/rl77_special_ammo'
local existing=rawget(_G,key)
if existing then return existing end
local function start()
    local hd2=runtime
    local mod=hd2.mod()
    local weapon=hd2.support_weapon('RL-77 Airburst Rocket Launcher')
    local feed=weapon:feed('programmable')
    local source=feed:source()
    assert(source.writable and source.target,'RL-77 programmable feed is not writable on this Runtime/build')
    local original=feed:projectile()
    local names={'原版特殊弹（集束）'}
    local values={original}
    local rows={
        {'TD-220 堡垒主炮弹','TD-220 Bastion MK XVI / attach_tank_gun'},
    }
    for _,row in ipairs(rows) do
        names[#names+1]=row[1]
        values[#values+1]=hd2.attack_output(row[2])
    end
    local page=hd2.options({id='luoshuilin_rl77_td220_v2',title='RL-77 原版与坦克弹'})
    local choice=page:choice({id='special_round',label='特殊模式弹药',choices=names,values=values,default=1,
        description='默认原版集束弹。APPLY后重新呼叫RL-77，长按换弹键并选择特殊模式。普通防空模式不变；不同炮弹使用各自弹道。'})
    local watch=hd2.ensure({patch={id='rl77-special-round',target=source.target,
        field=hd2.fields.function_ammo.projectile,expect=original,value=choice,
        allow_unverified_effect=true,allow_unverified_reference=true}})
    mod:log('RL77_SPECIAL_AMMO_MENU_INITIALIZED; default=native')
    return {watch=watch,choice=choice}
end
local state=runtime.events.run_as('mods/luoshuilin/rl77_special_ammo',start)
rawset(_G,key,state)
return state
