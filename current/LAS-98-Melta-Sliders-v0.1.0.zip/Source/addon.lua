-- HD2-Addon: mods/luoshuilin/las98_melta_sliders
-- v0.1.1: Loader Lua ABI version is separate from its release label.
-- v0.1.1: Loader Lua ABI version is separate from its release label.
-- Original preset is the default. No raw addresses or guessed damage owners.
local loader=rawget(_G,'CowboyBingusModLoader')
assert(loader and loader.api==1 and type(loader.version)=='number' and loader.version>=16,
    'Requires Bingus Shared Loader v18 / API 1')
local runtime=require('mods/skyeshade/hd2runtime')
local minimum='0.28.1'
local function at_least(current,required)
    local a,b,c=tostring(current):match('^(%d+)%.(%d+)%.(%d+)')
    local x,y,z=required:match('^(%d+)%.(%d+)%.(%d+)$')
    if not a then return false end
    a,b,c,x,y,z=tonumber(a),tonumber(b),tonumber(c),tonumber(x),tonumber(y),tonumber(z)
    return a>x or a==x and (b>y or b==y and c>=z)
end
assert(runtime.api_version==1 and at_least(runtime.version,minimum),
    'Requires HD2Runtime 0.28.1 / API 1')
local key='HD2RuntimeMod:mods/luoshuilin/las98_melta_sliders'
local existing=rawget(_G,key)
if existing then return existing end
local function start()
    local hd2=runtime
    local mod=hd2.mod()
    local state={watches={},menu_registered=false}
    local weapon=hd2.support_weapon('LAS-98 Laser Cannon')
    local attack=weapon:attack('primary')
    local damage=mod:value({id='damage',min=350,max=3500,step=50,default=350})
    local durable=mod:value({id='durable',min=200,max=3000,step=50,default=200})
    local ap=mod:value({id='ap',min=4,max=7,step=1,default=4})
    local capacity=mod:value({id='capacity',min=100,max=400,step=25,default=100})
    local cool=mod:value({id='cool',min=5,max=40,step=1,default=5})
    local spare=mod:value({id='spare',min=2,max=8,step=1,default=2})
    state.watches[1]=hd2.ensure({plan={id='las98-melta-plan',operations={
      {id='damage',target=attack,allow_shared=true,changes={
        {field=hd2.fields.damage.player_standard_damage,expect=350,value=damage},
        {field=hd2.fields.damage.player_durable_damage,expect=200,value=durable},
        {field=hd2.fields.damage.ap_direct,expect=4,value=ap},
        {field=hd2.fields.damage.ap_slight,expect=4,value=ap},
        {field=hd2.fields.damage.ap_large,expect=4,value=ap},
        {field=hd2.fields.damage.ap_extreme,expect=4,value=ap},
      }},
      {id='heat',target=weapon,allow_shared=true,changes={
        {field=hd2.fields.heat.capacity,expect=100,value=capacity},
        {field=hd2.fields.heat.cool_per_second,expect=5,value=cool},
      }},
      {id='spares',target=weapon,allow_shared=true,field=hd2.fields.heatsink.spare,expect=2,value=spare}
    }}})
    local elapsed=0
    local function register_menu()
      if state.menu_registered then return end
      local menu=rawget(_G,'ModOptionsMenu')
      if type(menu)~='table' or menu.api~=1 or type(menu.register_option)~='function' or type(menu.on_change)~='function' or type(menu.get)~='function' then return end
      do
        local id='luoshuilin.las98.melta.v1.damage'
        local ok,why=menu.register_option(id,{type='slider',mod='LAS-98 熔融光束',label='光束伤害',min=350,max=3500,step=50,default=350,description='最左原版；APPLY后重新呼叫装备。共享伤害可能影响激光哨戒炮。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n)
          if type(n)=='number' and n>=350 and n<=3500 then damage:set(n) end
        end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.las98.melta.v1.durable'
        local ok,why=menu.register_option(id,{type='slider',mod='LAS-98 熔融光束',label='耐久伤害',min=200,max=3000,step=50,default=200,description='最左原版；APPLY后重新呼叫装备。共享伤害可能影响激光哨戒炮。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n)
          if type(n)=='number' and n>=200 and n<=3000 then durable:set(n) end
        end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.las98.melta.v1.ap'
        local ok,why=menu.register_option(id,{type='slider',mod='LAS-98 熔融光束',label='穿甲等级',min=4,max=7,step=1,default=4,description='最左原版；APPLY后重新呼叫装备。共享伤害可能影响激光哨戒炮。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n)
          if type(n)=='number' and n>=4 and n<=7 then ap:set(n) end
        end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.las98.melta.v1.capacity'
        local ok,why=menu.register_option(id,{type='slider',mod='LAS-98 熔融光束',label='热容量',min=100,max=400,step=25,default=100,description='最左原版；APPLY后重新呼叫装备。共享伤害可能影响激光哨戒炮。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n)
          if type(n)=='number' and n>=100 and n<=400 then capacity:set(n) end
        end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.las98.melta.v1.cool'
        local ok,why=menu.register_option(id,{type='slider',mod='LAS-98 熔融光束',label='冷却速度',min=5,max=40,step=1,default=5,description='最左原版；APPLY后重新呼叫装备。共享伤害可能影响激光哨戒炮。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n)
          if type(n)=='number' and n>=5 and n<=40 then cool:set(n) end
        end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      do
        local id='luoshuilin.las98.melta.v1.spare'
        local ok,why=menu.register_option(id,{type='slider',mod='LAS-98 熔融光束',label='备用散热器',min=2,max=8,step=1,default=2,description='最左原版；APPLY后重新呼叫装备。共享伤害可能影响激光哨戒炮。'})
        if not ok then mod:log('MENU_REFUSED '..tostring(why));return end
        local function apply(n)
          if type(n)=='number' and n>=2 and n<=8 then spare:set(n) end
        end
        if menu.on_change(id,apply)~=true then mod:log('MENU_CALLBACK_REFUSED');return end
        apply(menu.get(id))
      end
      state.menu_registered=true;mod:log('SLIDERS_REGISTERED')
    end
    state.menu_timer=mod:every(1,function(timer)
      elapsed=elapsed+1;register_menu()
      if state.menu_registered or elapsed>=30 then timer:cancel() end
    end,{id='register-menu',scope='session'})
    return state
end
local state=runtime.events.run_as('mods/luoshuilin/las98_melta_sliders',start)
rawset(_G,key,state)
return state
