-- HD2-Addon: mods/combat/enemy_hp
-- Enemy HP 1.1.1: when you mark an enemy (red ping), its current / max HP shows under the marker, in the
-- ping's colour, for exactly as long as the game keeps the mark (8 s marks, multi-marks until cancelled or killed).
-- White ground pings and teammates' marks are ignored. READ-ONLY: reads the game's ping list, health data and unit
-- positions; writes nothing to the game.
-- Ping list layout (the game's ping UI ring) was learned from etxp's open-source HD2 G-60 Smart Targeting - thanks.
-- Settings: %LOCALAPPDATA%/Hd2EnemyHp/enemy_hp.cfg  (offset = label position in pixels, negative = below)
-- Supported game build: Steam 25480438 (checked at start; any other build -> the mod stays off and says so in its log).
local SHOW_NAME = true   -- build variant: label shows the enemy name too
local NAMES = {
    ["0002BA767DF856F3"] = "Marauder",
    ["019544309FAC4508"] = "AX/AR-23 Guard Dog MK2 (Drone)",
    ["01FE503DCD17847B"] = "Warp Ship Landed",
    ["021EAECF4CA267DC"] = "SEAF (City)",
    ["073270650F859DD0"] = "Dark Fluid Backpack",
    ["0736BEE2D6328726"] = "Lumberer Exosuit Flamer",
    ["0807D288AD22601B"] = "AX/AR-23 Guard Dog (Hellpod)",
    ["0883366204E1CCC5"] = "Gazer",
    ["089833D2880D9E06"] = "Incendiary MG Raider",
    ["08E6FFC2474287BD"] = "Overseer MK2",
    ["08F6089289C83D22"] = "Patriot Exosuit Gatling",
    ["09183066C4EBCE28"] = "SH-51 Directional Shield (Hellpod)",
    ["095686275A113614"] = "Shrieker Nest",
    ["09DFB04B2E578BC3"] = "Incendiary Rocket Trooper",
    ["09FE0BE51A23396C"] = "Female Agiator",
    ["0A03761D50BA5121"] = "Emancipator Exosuit Autocannon Right MK2",
    ["0A60397B7409995E"] = "StA-X3 W.A.S.P. Launcher (Hellpod)",
    ["0AB7B92B131C228C"] = "Rupture Charger",
    ["0AC9CDDBE8C64851"] = "B/MD C4 Pack (Hellpod)",
    ["0ADC9F9173AD8E1D"] = "Voteless Medium",
    ["0BD0F9D59048E9D1"] = "Eagle Fast Strike",
    ["0C8257D1C0255593"] = "E/GL-21 Grenadier Battlement",
    ["0D382AE7FFEA9D45"] = "Lightning Spire",
    ["0DC7A18342B62BEC"] = "EAT-17 Expendable Anti-Tank (Hellpod)",
    ["0E37A0FA0A978620"] = "Extractable Worker Female",
    ["0E977C49DB7604F9"] = "E/MG-101 HMG Emplacement",
    ["0FD8B759412815DD"] = "MG-206 Heavy Machine Gun (Hellpod)",
    ["10081ACEF6163EF6"] = "Bile Warrior",
    ["111BEED56922BF4C"] = "Extractable Worker Male MK4",
    ["130574E0FFFE0058"] = "GATER Oilcan",
    ["137988CEA16458F7"] = "Hulk Bruiser",
    ["1448D494665D01A0"] = "Gazer MK2",
    ["15031543894C3F3C"] = "Spore Spewer TCS",
    ["16023E554FEE830E"] = "Cyborg Tank LMG",
    ["16474112801385B6"] = "TD-220 Bastion MK XVI",
    ["17C5D12D8D5DEE2C"] = "Lumberer Exosuit Anti Tank Cannon",
    ["1897BDD32105D2DC"] = "Hulk Scorcher MK2",
    ["1980D92B619FF5FE"] = "E/MG-101 HMG Emplacement (Laser)",
    ["19E18B46EC55D94A"] = "Stingray",
    ["1A7FCDFF98C664B0"] = "Charger",
    ["1B3BCADABC7EF8D6"] = "Eagle Air Strike Smoke",
    ["1B5B9AC4F96B36E5"] = "Incendiary Commissar",
    ["1C6981CA2FB69508"] = "Factory Strider Gatling MK4",
    ["1E66EE1F6F7FD00E"] = "Hulk Obliterator",
    ["1F0A91729C0004E0"] = "Spore Burst Hunter",
    ["1FA1F596769225C2"] = "Bastion MK XVI Heavy Cannon",
    ["20225DEE487C9F5F"] = "GL-21 Grenade Launcher (Hellpod)",
    ["20AAFC3A504D2E5F"] = "EAT-700 Expendable Napalm (Hellpod)",
    ["20B9C7734DAEAD65"] = "Veracitor",
    ["215CE160A17BE4CD"] = "Jet Brigade Commissar",
    ["22CC0ED4CEB9CB68"] = "Fabricator MK2",
    ["23A60681DD4383EC"] = "Eagle Strafe Run",
    ["24510E7B16B5F7A5"] = "E/MG-101 HMG Emplacement (Railgun)",
    ["24ACA2B4D15D2E2F"] = "Power Generator",
    ["257D805CAA7E10C0"] = "Shotgun Trooper",
    ["25A2FD037B6ED25C"] = "MD-17 Anti-Tank Mine Deployer",
    ["27BB558C893383CC"] = "Eagle Napalm Airstrike (Shell)",
    ["282EB766C1FFA6A1"] = "Gunship",
    ["298C464F7F4261E3"] = "Command Bunker Wall",
    ["299C0D3DFD2F0994"] = "A/GM-17 Gas Mortar Sentry",
    ["29AE906EA485A7FA"] = "Starwart Defense Wall",
    ["2A12104F2853AE16"] = "Rocket Raider",
    ["2A346BF4552997E2"] = "Scout Strider HMG",
    ["2AD2E055DAD21F6E"] = "Warp Ship Invasion",
    ["2B11C9E4980EC479"] = "E/AT-12 Anti-Tank Emplacement",
    ["2C1A7790C435FD67"] = "Automaton LMG Emplacement",
    ["2CF3488C4845F8BD"] = "Cannon Turret",
    ["2D85BFE3D8717FE5"] = "M-104 Incinerator FRV",
    ["2EA01CB1676ACA29"] = "Eagle Airstrike",
    ["2F67BF9C4F560C02"] = "GL-52 De-Escalator (Hellpod)",
    ["304C3124208291E9"] = "Illuminate Drone",
    ["30CF04B2EC8C9BD4"] = "Scout Raider",
    ["30F2DEE2333F227A"] = "Jammer Factory Strider",
    ["31400A6A3003E29C"] = "B-1 Supply Pack (Hellpod)",
    ["31BAE74D2F064D8D"] = "Annihilator Tank MK2",
    ["31C4DD88C1450282"] = "M-105 Stalwart (Hellpod)",
    ["32541FC4EC7C9CDC"] = "Warrior MK3",
    ["32C7063B4BCC4208"] = "Emancipator Exosuit Autocannon Left MK2",
    ["32CDEADA234FB8DF"] = "Jet Brigade Hulk Bruiser",
    ["33B3E0CE8D179EEC"] = "Jet Brigade Devastator Backpack",
    ["341AF8820251A624"] = "Civilian MK5",
    ["34DFD23365472E9E"] = "Obtruder",
    ["353C5D1070126899"] = "Civilian MK3",
    ["356DE4A7808EF3E3"] = "Vox Engine Gatling Right",
    ["35DBF54F016F3624"] = "EXO-55 Breakthrough Exosuit",
    ["36390775D61159EB"] = "Annihilator Tank Fusion Repeater",
    ["36AA99CCE5E60146"] = "Bile Spewer",
    ["37079568DC86E9C6"] = "A/MLS-4X Rocket Sentry",
    ["37CDE43876BA26BB"] = "A/MG-43 Machine Gun Sentry",
    ["390E6B3D2F26BD70"] = "Factory Strider Gatling MK2 (Left)",
    ["397792815583DA29"] = "Eagle 110MM Rocket Pods",
    ["397FB7E4883AF100"] = "Reinforced Scout Strider Rocke Right",
    ["3A50B58B0553056A"] = "SH-20 Ballistic Shield Backpack (Hellpod)",
    ["3AAFBA89B53B0F63"] = "Factory Strider Gatling (Right)",
    ["3AFF5FD7D5450B99"] = "Charger Behemoth",
    ["3D0E03E2D574E1CA"] = "Hunter MK2",
    ["3E0537D606438FEA"] = "Hulk Scorcher",
    ["3E3A31261A124454"] = "Emancipator Exosuit Autocannon Right MK3",
    ["3F8734AEC15B82AD"] = "Pelican MK3",
    ["4019623142351CB6"] = "Trooper MK3",
    ["41436D438139F786"] = "AX/FLAM-75 Hot Dog (Hellpod)",
    ["4232EE48E2CFD24E"] = "Bulk Fabricator",
    ["423FF97D57AB04F5"] = "Ground All-Terrain Extraction Rig",
    ["426B3DF007BE9F18"] = "MG Raider Backpack",
    ["44458A2C52B002FB"] = "Voteless Heavy",
    ["4446E7312B401E69"] = "Illuminate Scrambler Battery",
    ["453FE22C634EB30F"] = "Gatekeeper",
    ["46B9E3BE0AE9972E"] = "PLAS-45 Epoch (Hellpod)",
    ["48C91E42B9F16512"] = "Factory Strider Gatling MK3",
    ["49674794A165EDA8"] = "Shredder Tank Fusion Autocannon",
    ["4ABCF54464695EFA"] = "Civilian",
    ["4B071633584E4594"] = "AX/FLAM-75 Hot Dog (Drone)",
    ["4C7E4680FF843A1B"] = "LIFT-182 Warp Pack (Hellpod)",
    ["4CF9D9B3F6813F52"] = "ARC-3 Arc Thrower (Hellpod)",
    ["4D19A06B81FA744A"] = "Civilian MK2",
    ["4D1C334D294DFA97"] = "Player Clone (Avatar)",
    ["4E342031A9D5C4F9"] = "Leviathan Beam Turret",
    ["4E97FB073BDC7A4B"] = "Warrior MK2 (Captive)",
    ["4EA134679A235BE0"] = "SEAF MK7",
    ["4FB8EB356AC8553E"] = "Fabricator MK4",
    ["5052EC6A928CCF1A"] = "Supplies (Hellpod)",
    ["5158E582FBEB26BD"] = "Fabricator",
    ["51A0812E3BCE2D74"] = "A/M-12 Mortar Sentry",
    ["51C6132EC1D10E7E"] = "Cyborg Tank Gatling",
    ["51EEA86BF6997E4E"] = "Scavenger MK2",
    ["52018DEB9AB6827E"] = "Jet Brigade Trooper (Crash)",
    ["52DCE8A110418742"] = "LIFT-860 Hover Pack (Hellpod)",
    ["53D8919D7B8ABD67"] = "Annihilator Tank",
    ["54D86057F5DACFB9"] = "A/AC-8 Autocannon Sentry",
    ["54E107DACF6929CB"] = "Berserker MK2",
    ["56070F36CFFFA8A8"] = "A/LAS-98 Laser Sentry",
    ["57EED0EAC346CD9D"] = "Incendiary Devastator",
    ["57F11209295752B5"] = "Pyro Trooper Backpack",
    ["57F27CBD5B71B0CB"] = "A/G-16 Gatling Sentry MK4",
    ["58B2B86C11369241"] = "Incendiary MG Devastator",
    ["5BEEC97F4C7F4AE9"] = "AX/LAS-5 Rover (Drone)",
    ["5CA832447445C0BA"] = "Hunter MK3",
    ["5CAF553BA7EA1429"] = "S-11 Speargun (Hellpod)",
    ["5D142C3A73EBC634"] = "Barrager Tank Ballistic Missile",
    ["5F41C4DCABE95421"] = "AC-8 Autocannon (Hellpod)",
    ["5F9AEAC72B738298"] = "SH-20 Ballistic Shield Backpack MK2",
    ["6021E22338333D88"] = "Nursing Spewer",
    ["604A794EC45BB820"] = "Elevated Overseer",
    ["611BA777783B08A2"] = "Vox Engine Cannon Turret",
    ["61353DF120F27732"] = "LIFT-850 Jump Pack (Hellpod)",
    ["6293CAF0559BACF6"] = "SOS Beacon",
    ["63DF3D07B7424588"] = "Barrager Tank",
    ["64090088502435DD"] = "Shrieker",
    ["64BA5F030B114EC1"] = "Raider",
    ["65489809A8181B96"] = "Breakthrough Exosuit Shield",
    ["672F7DA17F3BA34A"] = "Tentacle",
    ["674FB0849F8A1140"] = "Extractable Worker Male MK3",
    ["67AC082FF6D142F3"] = "LAS-99 Quasar Cannon (Hellpod)",
    ["67DC32DCA4F02D33"] = "Fleshmob",
    ["68A34D32A1025F04"] = "A/G-16 Gatling Sentry MK5",
    ["6A7A54D5FB3A6D17"] = "Factory Strider Gatling MK5",
    ["6B09879E8677752D"] = "Civilian MK4",
    ["6B202392F4AB605E"] = "Spore Charger",
    ["6B6E7FE1B931393C"] = "Dark Fluid Backpack (Hellpod)",
    ["6DAB2EADF5D8B692"] = "Hulk Firebomber",
    ["6E499C5C95B019FC"] = "Command Bunker",
    ["728421351D440EBC"] = "Spore Burst Warrior",
    ["72A83E49CED6DB3D"] = "Bile Spitter",
    ["72DB04413D4AB0F0"] = "AX/FLAM-75 Hot Dog (Hellpod)",
    ["73B63D637973C7A4"] = "M-1000 Maxigun (Hellpod)",
    ["74599E56F72F9D7E"] = "A/ARC-3 Tesla Tower",
    ["746A7F3BEDA32699"] = "Male Radical",
    ["74E2285C01DA4F71"] = "Warp Ship",
    ["75BE82ED8592A6B3"] = "Pelican Transport",
    ["76070813B0D1C473"] = "SEAF MK5",
    ["76AC2C791CE6EB5B"] = "SEAF MK3",
    ["77C52E494527AA8A"] = "B-100 Portable Hellbomb (Hellpod)",
    ["78E1497571012C47"] = "Voteless Light",
    ["79E4B3D2DA5E45E3"] = "EXO-45 Patriot Exosuit",
    ["7A3637CD33A54E4C"] = "SEAF",
    ["7ACB4BD753B71DE0"] = "Leviathan Beam Turret Right",
    ["7B0F8449CA9D2DA0"] = "Pelican MK2",
    ["7B2326F6FD9C8069"] = "EXO-51 Lumberer Exosuit",
    ["7B48CACDBACB3881"] = "Trooper MK2",
    ["7BB964A9DB5EE774"] = "SEAF MK2",
    ["7EA558204D0FFC29"] = "Overseer Shield",
    ["7ECE5304F868F6B3"] = "Trooper (No Package)",
    ["7FA006885812A756"] = "CQC-9 Defoliation Tool (Hellpod)",
    ["7FF0FD4572F5996F"] = "A/G-16 Gatling Sentry MK2",
    ["820CC3BAFE962858"] = "A/FLAM-40 Flame Sentry",
    ["824B7E0C4C879EB5"] = "Patriot Exosuit Rocket Launcher",
    ["82A87AD8D595B2BA"] = "Pyro Trooper",
    ["8365609B35EF6672"] = "Pelican Turret",
    ["8372619B2702D743"] = "War Strider Cannon Left",
    ["843D18D4B5512B63"] = "Factory Strider Cannon Turret",
    ["84F256FBF7B0BCC1"] = "Gate",
    ["856E9710E45E760F"] = "Jet Brigade Raider",
    ["8633FF89EF4F6788"] = "A/AC-8 Autocannon Sentry Plasma",
    ["8661CA5CF58D8162"] = "Extractable Worker Female MK2",
    ["87F46B6D12BB016A"] = "A/G-16 Gatling Sentry MK3",
    ["883401AF2A98A5F6"] = "Predator Hunter",
    ["888EAAFD58C03C75"] = "Cargo Truck",
    ["891ADA7D553B69DB"] = "APW-1 Anti-Materiel Rifle (Hellpod)",
    ["8A9E543022C18092"] = "EAT-411 Leveller (Hellpod)",
    ["8CA4DFA795A473C8"] = "Emancipator Exosuit Autocannon Left MK3",
    ["8D435A5C9A304215"] = "Extractable Worker Female MK3",
    ["8DB8B823889324F9"] = "CQC-20 Breaching Hammer (Hellpod)",
    ["8FB47DD28B398CF7"] = "Annihilator Tank Heavy Fusion Cannon",
    ["8FC2784308E9BA99"] = "Hulk Obliterator Flag",
    ["8FF0A839830A7692"] = "Scavenger",
    ["9076EEED17FCEE35"] = "Reinforced Scout Strider",
    ["91EBD77931110AFC"] = "Heavy Devastator MK3",
    ["9402B0FC52136A70"] = "Civilian MK8",
    ["94C5114EBA59AA21"] = "MG-43 Machine Gun (Hellpod)",
    ["960B48A421A3FAAA"] = "Dragonroach",
    ["9647B00CC3A9D36F"] = "Rocket Devastator",
    ["965EAE5A51ACDD4A"] = "Harvester",
    ["967ED15E0BAE363B"] = "SH-20 Ballistic Shield Backpack",
    ["96BA14C9EBB49CE1"] = "Hulk",
    ["972BAAC825D4D165"] = "Annihilator Tank Heavy Fusion Repeater",
    ["975927D040D1543D"] = "SEAF MK8",
    ["979E9BC6D48D1FC6"] = "AX/FLAM-75 Hot Dog (Drone)",
    ["98152772A72F7838"] = "Dropship",
    ["9872EEB31A5F88FD"] = "GATER Turret",
    ["9926876B2375A1BB"] = "Bunker Turret",
    ["9A8A3AAE287B230C"] = "Scavenger MK3",
    ["9AB036439F74C115"] = "War Strider Cannon Right",
    ["9B2140378640432E"] = "M-103 Supply FRV",
    ["9B75217D8312DD67"] = "C4",
    ["9D4F7CB4EB34515D"] = "Eagle Cluster Bomb",
    ["9D8827FED763650E"] = "Male Agitator",
    ["9E2E17F2CCCCAFDD"] = "Bile Titan",
    ["9E83637BB077E782"] = "M-103 Supply FRV Supply Box",
    ["9EA89CEEA6F8E766"] = "Larva Container",
    ["9ECFEA53BCB158BF"] = "SEAF MK4",
    ["9F0245AA414CA45C"] = "SEAF MG",
    ["9F57782F00E6ED20"] = "Trooper",
    ["A05BD1EC67B3AC4C"] = "Charger Behemoth MK2",
    ["A0E691598F32932F"] = "MLS-4X Commando (Hellpod)",
    ["A0FF2F9A0CA6992A"] = "AX/AR-23 Guard Dog (Drone)",
    ["A1A7B76B29088843"] = "Fabricator MK5",
    ["A1F37BF2A40FBDE4"] = "Hive Guard",
    ["A20683199DFC19E8"] = "TM-1 Lure Mine",
    ["A35207C6F2150806"] = "Rupture Warrior",
    ["A381A11C07D3EB94"] = "Rupture Spewer",
    ["A4552F97033392F4"] = "Jet Brigade MG Raider",
    ["A4E796F84801B40A"] = "SH-51 Directional Shield",
    ["A6A68D8AF177F3A1"] = "Berserker",
    ["A71AAFD82C6EBC92"] = "Commissar",
    ["A8173FBA5DEC35C3"] = "Reinforced Scout Strider Rocke Left",
    ["A970CBA66FBEAA11"] = "E/MG-101 HMG Emplacement MK2",
    ["A98F8B559C7993D8"] = "Automaton HMG Emplacement",
    ["A9982969137F3D77"] = "MD-8 Gas Mine Deployer",
    ["AA28CAF964D05500"] = "Spore Spewer",
    ["AA4564F90CDBF5F1"] = "A/MG-43 Machine Gun Sentry MK2",
    ["AAB438596F5E8FD9"] = "Pouncer",
    ["ABDB2E2A0479D8CA"] = "Cannon Turret MK2",
    ["AC60E78435098C9D"] = "Watcher",
    ["ADD299F56916AE1F"] = "Explosive Barrel",
    ["AE57FCDB49F74E98"] = "Trooper MK2 MG",
    ["AE63E525853D7044"] = "Devastator MK3",
    ["AEAEF7A1851E6C9D"] = "Automaton AA Emplacement",
    ["AF04113302F5621D"] = "Medical Supply (Hellpod)",
    ["AF0F9B3A163787A5"] = "Jet Brigade Trooper",
    ["AFC719AF96F10DC3"] = "Infested Tower",
    ["B056F8FC74ABA02D"] = "Cannon Trooper",
    ["B0C9FAF4AF8903F9"] = "Maelstrom Tank",
    ["B2053A1838092F8B"] = "A/M-23 EMS Mortar Sentry",
    ["B2A6FA1E4284C7E6"] = "Warrior(Spawned)",
    ["B3F6EC87073AAFEC"] = "Medic Backpack (Hellpod)",
    ["B4ED319B39F5457B"] = "MG Raider",
    ["B52BEAAE4F85C391"] = "Sealed Hellpod",
    ["B56FA3F5510000AB"] = "SH-51 Directional Shield (Shield)",
    ["B5DBC0C240C921AD"] = "Incendiary Berserker",
    ["B62620AE2CD89F49"] = "RS-422 Railgun (Hellpod)",
    ["B7791DA91F13488C"] = "GL-28 Belt-Fed Grenade Launcher (Hellpod)",
    ["B8580CAC32214FC0"] = "Cyborg Tank Cannon Turret",
    ["B92435FBF60F0748"] = "Heavy Devastator MK2",
    ["B940C889D77F8219"] = "Jet Brigade Hulk Backpack",
    ["B971B1141E1CBFAC"] = "Factory Strider Scrambler",
    ["B9BAF571FC8F9959"] = "AX/TX-13 Dog Breath (Drone)",
    ["BAF9DBD86B22270A"] = "Overship",
    ["BBD57DF3E5B15ED8"] = "TX-41 Sterilizer (Hellpod)",
    ["BC242702FB46B7E7"] = "Vox Engine",
    ["BE39E313A1E46BB9"] = "Warrior MK2",
    ["BE743B2FAA3A6E26"] = "Jet Brigade Devastator",
    ["BF32E12923A9A252"] = "MD-14 Incendiary Mine Deployer",
    ["BF4167FD26917AB1"] = "Emancipator Exosuit Autocannon",
    ["C2B9EB21B06F8378"] = "Hulk Firebomber Flag",
    ["C2D449ECF7FACAB1"] = "Emancipator Exosuit",
    ["C2D93163FDBB14A1"] = "Extractable Worker Male MK2",
    ["C57F85252B7D853B"] = "FAF-14 Spear (Hellpod)",
    ["C626D2BB495A202D"] = "Devastator",
    ["C6449FFD9EA3779C"] = "Shredder Tank",
    ["C6A87C428FD3C7A3"] = "Hellbomb",
    ["C87555EED1E9F092"] = "MGX-42 Bullet Storm (Hellpod)",
    ["C9BCCCB0A54A82A4"] = "Incendiary Rocket Devastator",
    ["CA4F3FC268F449D5"] = "B/FLAM-80 Cremator (Hellpod)",
    ["CA6E81E2B3E22B18"] = "RL-77 Airburst Rocket Launcher (Hellpod)",
    ["CBB1BA3366009C3A"] = "Female Radical",
    ["CC16FF3A5EEB6D83"] = "Civilian MK6",
    ["CC21C7FFD3EBEFB9"] = "M-102 Fast Recon Vehicle",
    ["CC7022FDD172089B"] = "Nursing Spewer MK2",
    ["CCAE5264ACD591B7"] = "Bile Spewer MK2",
    ["CD28A27A79BE53D5"] = "Command Bunker HMG",
    ["D108B49CE580B5C5"] = "Pelican SEAF Squad",
    ["D1E990BAF22D5A52"] = "Predator Stalker",
    ["D357DEE3CC202BD3"] = "Gate MK2",
    ["D37E8D120D2836E3"] = "Factory Strider",
    ["D3CD6F0CA83BB51E"] = "Reinforced Scout Strider Fullcover Cabin",
    ["D465D9C7F77A07CB"] = "Hivelord",
    ["D522FD4748D443A5"] = "Brood Commander",
    ["D5792F6856B06BA4"] = "Jet Brigade Berserker",
    ["D5A6ABA03479CFB8"] = "Extractable Worker Female MK4",
    ["D63FCBFF0851B7AF"] = "Harvester MK2",
    ["D8CBC4A807A6D035"] = "Brawler",
    ["D8E278355CF29EF4"] = "AX/TX-13 Dog Breath (Hellpod)",
    ["D9511E9F6BD62E3F"] = "Hunter",
    ["DA40BB347C7447F2"] = "Overseer",
    ["DB964631BE1CF501"] = "Spore Burst Scavenger",
    ["DC901B71A3A73B9A"] = "Spore Lung",
    ["DCF8E74212FBEE3B"] = "Impaler",
    ["DDDB2910FF2B24E9"] = "Mini Missile Silo (Missile, Model)",
    ["DDEE9646723E09D3"] = "GR-8 Recoilless Rifle (Hellpod)",
    ["DE18775FA447A9BF"] = "Mini Missile Silo (Hellpod)",
    ["DE6F09BC8EAEBE27"] = "AX/LAS-5 Rover (Hellpod)",
    ["DF3C4F91E298BFA4"] = "Hive Breaker Drill",
    ["DF51FE8D62F294BE"] = "Breakthrough Exosuit Heavy Shotgun",
    ["DFBACBD977A948DC"] = "Scavenger MK2 (Captive)",
    ["DFBB9A0D8FA27D85"] = "Eagle Air-To-Air Missiles",
    ["E02E6BD34B606A85"] = "Spore Spewer MK2",
    ["E0353177F1329573"] = "Conflagration Devastator",
    ["E0E257B37526DBE3"] = "E/MG-101 HMG Emplacement (Flamethrower)",
    ["E2E62FDD39407FE3"] = "Jet Brigade Conscript Backpack",
    ["E2E6E77DCC99A1CB"] = "Bio-Processor",
    ["E44B691DC039A505"] = "Eagle 500KG Bomb",
    ["E44EC9F9B3FE1D2A"] = "Jet Brigade Hulk Scorcher",
    ["E515A723DE95DC3D"] = "Civilian MK7",
    ["E5F64DCC3BFE9DD1"] = "Emancipator Exosuit Autocannon Left",
    ["E683D2CA5618D74A"] = "Incendiary Raider",
    ["E8E7D998FCBD32F8"] = "Illuminate Tesla Tower",
    ["E8F19A0AA958E46D"] = "Crescent Overseer",
    ["E90F771A36FB441E"] = "FLAM-40 Flame Thrower (Hellpod)",
    ["E9CD1D0D118886AF"] = "M-102 Fast Recon Vehicle (Map Spawn)",
    ["EA6959232BB47D4B"] = "SEAF MK6",
    ["EACEE39FA017B495"] = "Warrior",
    ["EB91B90EEC279745"] = "E/MG-101 HMG Emplacement (Rocket)",
    ["EB95609DCBAD53FE"] = "CQC-1 One True Flag (Hellpod)",
    ["ED13DDC480EC6910"] = "FX-12 Shield Generator Relay",
    ["EE00BFE8FF769F70"] = "Scout Strider Cabin",
    ["EF04CB84D097A497"] = "Spore Burst Bile Titan",
    ["EF570293245A17C2"] = "War Strider",
    ["EF85D6CF58E31D70"] = "A/G-16 Gatling Sentry",
    ["F00C349422E8E320"] = "MD-6 Anti-Personnel Mine Deployer",
    ["F0B98FB953B13960"] = "Fabricator MK3",
    ["F1610AC48CDC5240"] = "Overseer (No Package)",
    ["F196069E7E14C497"] = "Leviathan Beam Turret Left",
    ["F22D027B37BEF107"] = "Leviathan",
    ["F2881F5807348116"] = "Vox Engine Gatling Left",
    ["F540CA9D9D4A422E"] = "Stalker",
    ["F5C67AED5CB5ACA0"] = "SH-20 Ballistic Shield Backpack MK3",
    ["F66D0BAD8693779A"] = "Rocket Devastator MK2",
    ["F79CD8BB654397DF"] = "Alpha Commander",
    ["F800D5F62789246C"] = "AX/AR-23 Guard Dog MK3 (Drone)",
    ["F8131632AA867107"] = "Scout Strider",
    ["F88D61A8FE1E0766"] = "SH-32 Shield Generator Pack (Hellpod)",
    ["F8B5A81A86D5D4EB"] = "Heavy Devastator",
    ["F903A153F47AD10F"] = "Extractable Worker Male",
    ["F96257FCAE258CAA"] = "Defeat Devastator Shield",
    ["F9D5219640D65EF9"] = "AX/AR-23 Guard Dog MK4 (Drone)",
    ["FB293A4018D14EEA"] = "Cyberstan Wall Gate",
    ["FB9937035D652C43"] = "Trooper",
    ["FC8DEC78BE8AB47D"] = "Devastator MK2 Spawn",
    ["FDE262593307CA2F"] = "LAS-98 Laser Cannon (Hellpod)",
    ["FDFADE29AE5FE1D0"] = "Illuminate Explosive Barrel",
    ["FEB484EE972469F7"] = "Incendiary Devastator Shield",
    ["FF5CC825B9571052"] = "Automaton Mortar Emplacement",
    ["FF9878576A4C543B"] = "Emancipator Exosuit Autocannon Right",
}
-- (body of enemy_hp.lua; make_enemy_hp.py prepends the header and the NAMES table)
local state = rawget(_G, "EnemyHp")
if state and state.revision == "ehp-1.1.2-menu" then return end
local REVISION = "ehp-1.1.2-menu"
state = { revision = REVISION, frames = 0, status = "starting" }
rawset(_G, "EnemyHp", state)

-- ------------------------------------------------------------------ config --
-- %LOCALAPPDATA%/Hd2EnemyHp/enemy_hp.cfg:  offset=-40  (label position in pixels from the marked point; - = below)
local OFFSET = -40

local function read_overrides()
    local base = os.getenv("LOCALAPPDATA")
    if not base then return end
    local ok, f = pcall(io.open, base .. "/Hd2EnemyHp/enemy_hp.cfg", "r")
    if not ok or not f then return end
    for line in f:lines() do
        local k, v = line:match("^%s*([%a_]+)%s*=%s*(%-?[%d%.]+)")
        v = v and tonumber(v)
        if k == "offset" and v and v >= -400 and v <= 400 then OFFSET = v end
    end
    f:close()
end

-- --------------------------------------------------------------------- ffi --
local ok_ffi, ffi = pcall(require, "ffi")
if not ok_ffi then state.status = "no_ffi" return end
pcall(ffi.cdef, [=[typedef struct { void *base; void *allocation_base; uint32_t allocation_protection; uint16_t partition;
                     uint16_t reserved; size_t size; uint32_t state; uint32_t protection; uint32_t type; } EhpRegion;]=])
for declaration in ([=[
    void *GetCurrentProcess(void);
    void *GetModuleHandleA(const char *name);
    int ReadProcessMemory(void *process, const void *address, void *buffer, size_t size, size_t *read);
    
    size_t VirtualQuery(const void *address, void *region, size_t size);
    int CreateDirectoryA(const char *path, void *security);
    uint32_t GetLastError(void);
]=]):gmatch('[^;]+;') do pcall(ffi.cdef,declaration) end
local kernel = ffi.load("kernel32")
local sr = rawget(_G, "stingray")
local process = kernel.GetCurrentProcess()

-- ------------------------------------------------------------------ logging --
local out_dir
do
    local base = os.getenv("LOCALAPPDATA")
    if base then
        local d = base .. "/Hd2EnemyHp"
        if kernel.CreateDirectoryA(d, nil) ~= 0 or kernel.GetLastError() == 183 then out_dir = d end
    end
end
local log_started = false
local function log(line)
    print("[EnemyHp] " .. line)
    if not out_dir then return end
    local ok, f = pcall(io.open, out_dir .. "/EnemyHp.log", log_started and "a" or "w")
    log_started = true
    if ok and f then pcall(f.write, f, line .. string.char(10)); pcall(f.close, f) end
end

-- ------------------------------------------------------------------ memory --
local BIG = 1048576
local big = ffi.new("uint8_t[?]", BIG)
local small = ffi.new("uint8_t[512]")
local got = ffi.new("size_t[1]")

local function rd(address, size)              -- small reads (<= 512) as Lua strings
    if not address or address < 65536 or size <= 0 or size > 512 then return nil end
    if kernel.ReadProcessMemory(process, ffi.cast("const void *", address), small, size, got) == 0 then return nil end
    if got[0] ~= size then return nil end
    return ffi.string(small, size)
end
local function u32(s, o) local a, b, c, d = s:byte(o + 1, o + 4) return a + b * 256 + c * 65536 + d * 16777216 end
local function i32(s, o) local v = u32(s, o) if v >= 2147483648 then v = v - 4294967296 end return v end
local fbox = ffi.new("float[1]")
local function f32(s, o) ffi.copy(fbox, s:sub(o + 1, o + 4), 4) return tonumber(fbox[0]) end
local function ptr(a) local s = rd(a, 8) if not s then return nil end local v = u32(s, 0) + u32(s, 4) * 4294967296
    if v < 65536 or v >= 0x800000000000 then return nil end return v end
local function hex64(s, o) return string.format("%08X%08X", u32(s, o + 4), u32(s, o)) end

local region = ffi.new("EhpRegion[1]")
local function region_info(address)
    if kernel.VirtualQuery(ffi.cast("const void *", address), region, ffi.sizeof(region[0])) == 0 then return nil end
    return { base = tonumber(ffi.cast("uintptr_t", region[0].base)), alloc = tonumber(ffi.cast("uintptr_t", region[0].allocation_base)),
             size = tonumber(region[0].size), state = region[0].state, prot = region[0].protection, type = region[0].type }
end

local game = tonumber(ffi.cast("uintptr_t", kernel.GetModuleHandleA("game.dll")))
local exe = tonumber(ffi.cast("uintptr_t", kernel.GetModuleHandleA(nil)))

-- Unit root position from the exe unit registry (method of Stim Homing's port: registry exe+0x1a100f0,
-- index = unit % 0x400000, generation byte, object+8 = unit id, bone matrices ptr(object+0x88), position at +48).
local pose_ok = nil
local function unit_position(unit)
    local reg = ptr(exe + 0x1a100f0); if not reg then return nil end
    local index, generation = unit % 0x400000, math.floor(unit / 0x400000) % 256
    local c = rd(reg + 0x98, 4); if not c or index >= u32(c, 0) then return nil end
    local gp = ptr(reg + 0xa0); local gb = gp and rd(gp + index, 1)
    if not gb or gb:byte() ~= generation then return nil end
    local tbl = ptr(reg + 0x88); local obj = tbl and ptr(tbl + 8 * index)
    if not obj then return nil end
    local idb = rd(obj + 8, 4); if not idb or u32(idb, 0) ~= unit then return nil end
    if pose_ok == nil then
        local m = ptr(obj); local meth = m and ptr(m + 0xe8)
        pose_ok = (meth and rd(meth, 5) == "\x48\x8d\x41\x60\xc3") or false
        if not pose_ok then log("unit pose layout changed on this build; label stays at screen centre") end
    end
    if not pose_ok then return nil end
    local bones = ptr(obj + 0x88); local b = bones and rd(bones + 48, 12)
    if not b then return nil end
    local x, y, z = f32(b, 0), f32(b, 4), f32(b, 8)
    if x ~= x or y ~= y or z ~= z or math.abs(x) > 1e5 or math.abs(y) > 1e5 or math.abs(z) > 1e5 then return nil end
    return x, y, z
end

-- ------------------------------------------------------------ health data --
-- Health manager (as DRIVER HUD): count u32 at hm+0x1020, descriptor pointers at ptr(hm+0x1048),
-- records ptr(hm+0x1058) + j*0x1B8 (+0x14 current HP). Descriptor: [u64 type][u32 entity][u32 unit][u32 goid][u32 flags].
local function health_units()
    local hm = ptr(game + 0x3326688); if not hm then return nil end
    local c = rd(hm + 0x1020, 4); if not c then return nil end
    local n = u32(c, 0); if n > 2048 then return nil end
    local arr, recs = ptr(hm + 0x1048), ptr(hm + 0x1058)
    if not arr or not recs then return nil end
    local out = {}
    for j = 0, n - 1 do
        local d = ptr(arr + j * 8)
        local db = d and rd(d, 24)
        if db then
            local unit = u32(db, 12)
            local hp = rd(recs + j * 0x1B8 + 0x14, 4)
            out[unit] = { j = j, type = hex64(db, 0), hp = hp and i32(hp, 0) or nil, entity = u32(db, 8) }
        end
    end
    return out
end
local function unit_of_entity(hu, entity)
    for unit, rec in pairs(hu) do if rec.entity == entity then return unit, rec end end
    return nil
end

-- Max HP from the HealthComponentData settings (health table at network root + 0xF12B78, as DRIVER HUD).
local max_cache = {}
local function max_hp(type_hex)
    if max_cache[type_hex] ~= nil then return max_cache[type_hex] or nil end
    local net = ptr(game + 0x346BF98); local t = net and ptr(net + 0xF12B78)
    local result = false
    if t then
        local key = ffi.new("uint64_t", tonumber(type_hex:sub(1, 8), 16)) * 4294967296 + tonumber(type_hex:sub(9), 16)
        local start = tonumber(key % 1002)
        for step = 0, 63 do
            local b = rd(t + ((start + step) % 1002) * 16, 16)
            if not b then break end
            local k = hex64(b, 0)
            if k == type_hex then
                local idx = u32(b, 8)
                if idx < 1002 then
                    local m = rd(t + 0x3EA0 + idx * 0x5650, 4)
                    if m then local v = u32(m, 0) if v > 0 and v < 10000000 then result = v end end
                end
                break
            elseif k == "0000000000000000" then break end
        end
    end
    max_cache[type_hex] = result
    return result or nil
end

-- ------------------------------------------------------------ ping colour --
-- Colour follows the game's own ping classification: SpottableComponentData (block 0A5E53DB) MarkerType at +0x14,
-- 72-byte records. Block found in the entity blob by its header; slot count = largest N where every key is reachable
-- from key % N (same method as Hellpod Optimization).
local SPOT_HASH, SPOT_STRIDE = 0x0A5E53DB, 72
local spot = nil          -- { keys = uint64[], idx = {}, N, base } or false when unavailable
local U64_0 = ffi.new("uint64_t", 0)
local U64_LIMIT = ffi.new("uint64_t", 100000)
local function blob_base()
    local net = ptr(game + 0x346BF98); local t = net and ptr(net + 0xF12B78)
    local r = t and region_info(t)
    if not r then return nil end
    local head = rd(r.alloc, 16)
    if not head or u32(head, 0) ~= 0x80C1CA70 or head:sub(5, 8) ~= "LDLD" or u32(head, 12) ~= 0x80C1CA70 then return nil end
    return r.alloc
end
local function load_spot()
    local base = blob_base(); if not base then return false end
    local sig = string.char(0xDB, 0x53, 0x5E, 0x0A) .. "LDLD" .. string.char(1, 0, 0, 0, 0xDB, 0x53, 0x5E, 0x0A)
    -- the block sits at blob+0x5A6668 on this build; search around it, then the whole blob
    local blk
    for _, span in ipairs({ { 0x5A0000, 0x20000 }, { 0, 0x2C80000 } }) do
        local off = span[1]
        while off < span[1] + span[2] and not blk do
            local n = math.min(BIG, span[1] + span[2] - off)
            if kernel.ReadProcessMemory(process, ffi.cast("const void *", base + off), big, n, got) == 0 then break end
            local i = ffi.string(big, n):find(sig, 1, true)
            if i then blk = base + off + i - 1 + 4 end
            off = off + n - 16
        end
        if blk then break end
    end
    if not blk then log("ping colours unavailable (spottable table not found)") return false end
    local hdr = rd(blk, 16); local size = u32(hdr, 12)
    local limit = math.min(4000, math.floor(size / 16))
    if kernel.ReadProcessMemory(process, ffi.cast("const void *", blk + 0x18), big, limit * 16, got) == 0 then return false end
    local q = ffi.cast("const uint64_t *", big)
    local keys = ffi.new("uint64_t[?]", limit + 1); local idx = {}; local bound = 0
    for i = 0, limit - 1 do
        local k, v = q[i * 2], q[i * 2 + 1]
        if k ~= U64_0 and v > U64_LIMIT then break end
        keys[i] = k; idx[i] = tonumber(v); bound = i + 1
    end
    local function fits(N)
        local any = false
        for i = 0, N - 1 do
            local k = keys[i]
            if k ~= U64_0 then
                any = true
                local j = tonumber(k % N)
                while j ~= i do if keys[j] == U64_0 then return false end j = (j + 1) % N end
            end
        end
        return any
    end
    local N
    for n = bound, 1, -1 do if fits(n) then N = n break end end
    if not N or (size - N * 16) % SPOT_STRIDE ~= 0 then log("ping colours unavailable (spottable layout changed)") return false end
    log(string.format("ping colours: spottable table at blob+0x%X, %d slots", blk - base, N))
    return { keys = keys, idx = idx, N = N, base = blk + 0x18 + N * 16 }
end
-- Spottable record of an entity type: { marker, r0, r1, range } (radius at min / max range, max range) or false.
local spot_cache = {}
local function spot_of(type_hex)
    if spot_cache[type_hex] ~= nil then return spot_cache[type_hex] end
    if spot == nil then spot = load_spot() end
    local out = false
    if spot then
        local key = ffi.new("uint64_t", tonumber(type_hex:sub(1, 8), 16)) * 4294967296 + tonumber(type_hex:sub(9), 16)
        local j = tonumber(key % spot.N)
        for _ = 1, spot.N do
            local k = spot.keys[j]
            if k == key then
                local r = rd(spot.base + spot.idx[j] * SPOT_STRIDE, 0x18)
                if r then
                    local m = u32(r, 0x14)
                    out = { marker = m < 64 and m or false, r0 = f32(r, 4), r1 = f32(r, 8), range = f32(r, 0x10) }
                end
                break
            end
            if k == U64_0 then break end
            j = (j + 1) % spot.N
        end
    end
    spot_cache[type_hex] = out
    return out
end
local function marker_of(type_hex)
    local sp = spot_of(type_hex)
    return sp and sp.marker or false
end
-- HudMarkerType -> colour (a, r, g, b): enemies red, objectives yellow, mines/barrels orange, everything else white.
local function ping_colour(m)
    if m == 1 or m == 2 or m == 3 or m == 4 then return { 255, 235, 60, 50 } end
    if m == 17 or m == 18 then return { 255, 255, 213, 0 } end
    if m == 16 then return { 255, 255, 150, 40 } end
    return { 255, 240, 240, 240 }
end

-- ------------------------------------------------------------------- target --
local target = nil        -- { unit, type, name, max, until_t, dead_t, entity, colour, off }
local last_hp = nil
local function name_of(t) return NAMES[t] or "Target" end

-- ------------------------------------------------------------- ping ring --
-- The game's ping UI ring (layout from etxp/HD2-G60-Smart-Targeting, MIT; verified on this build 2026-09-27):
-- ring = ptr(game+0x347ce30); header byte0 == 1 when active, head u32 +8, tail u32 +12 (< 128); records of 0x58 at
-- ring+16+slot*0x58: +0x00 kind (1 = entity mark, 0 = ground ping), +0x10 duration, +0x14 age, +0x18 creator entity,
-- +0x20 marked entity. The local ping creator is the entry of the actor list ptr(game+0x3326d20) (count +0x70,
-- descriptors at +0x110+i*8) whose flags & 3 == 1.
local function local_creator()
    local actors = ptr(game + 0x3326d20); if not actors then return nil end
    local c = rd(actors + 0x70, 4); if not c then return nil end
    local n = u32(c, 0); if n > 16 then return nil end
    for i = 0, n - 1 do
        local d = ptr(actors + 0x110 + i * 8)
        local b = d and rd(d, 24)
        if b and (u32(b, 20) % 4) == 1 then return u32(b, 8) end
    end
    return nil
end
-- Newest live entity mark made by the local player: { entity, age, slot } or nil.
local function newest_mark(creator)
    local ring = ptr(game + 0x347ce30); if not ring then return nil end
    local h = rd(ring, 16)
    if not h or h:byte(1) ~= 1 then return nil end
    local head, tail = u32(h, 8), u32(h, 12)
    if head >= 128 or tail >= 128 then return nil end
    local best
    for step = 0, (tail - head) % 128 - 1 do
        local slot = (head + step) % 128
        local r = rd(ring + 16 + slot * 0x58, 0x24)
        if r then
            local kind, dur, age, who, what = u32(r, 0), f32(r, 0x10), f32(r, 0x14), u32(r, 0x18), u32(r, 0x20)
            if kind ~= 0 and who == creator and what ~= 0 and what ~= 0xFFFFFFFF and age >= 0 and age < dur then
                if not best or age < best.age then best = { entity = what, age = age, slot = slot, kind = kind } end
            end
        end
    end
    return best
end
local function entity_marked(creator, entity)
    local ring = ptr(game + 0x347ce30); if not ring then return false end
    local h = rd(ring, 16)
    if not h or h:byte(1) ~= 1 then return false end
    local head, tail = u32(h, 8), u32(h, 12)
    if head >= 128 or tail >= 128 then return false end
    for step = 0, (tail - head) % 128 - 1 do
        local r = rd(ring + 16 + ((head + step) % 128) * 0x58, 0x24)
        if r and u32(r, 0) ~= 0 and u32(r, 0x18) == creator and u32(r, 0x20) == entity and f32(r, 0x14) < f32(r, 0x10) then return true end
    end
    return false
end
local last_mark = nil
local function ring_step(now)
    local creator = local_creator(); if not creator then return end
    -- the label follows the game's mark: gone (expired / cancelled with the ping key) -> label gone
    if target and target.entity and not target.dead_t and state.frames % 6 == 0 then
        if entity_marked(creator, target.entity) then target.until_t = now + 0.5
        else target = nil; last_hp = nil end
    end
    local m = newest_mark(creator)
    if not m then return end
    -- a record is new when this slot was never seen with this entity, or the slot was reused (age went down)
    state.seen = state.seen or {}
    local key = m.slot .. ":" .. m.entity
    local prev = state.seen[key]
    local fresh = (prev == nil) or (m.age < prev - 0.05)
    state.seen[key] = m.age
    last_mark = m
    if not fresh then return end
    local hu = health_units(); if not hu then return end
    local unit, rec = unit_of_entity(hu, m.entity)
    if not unit or not rec.hp or rec.hp <= 0 then log("marked entity " .. m.entity .. " has no live health record") return end
    local mx = max_hp(rec.type)
    if not mx or rec.hp > mx then mx = rec.hp end
    target = { unit = unit, type = rec.type, name = name_of(rec.type), max = mx, until_t = now + 0.5, entity = m.entity }
    target.marker = marker_of(rec.type)
    target.colour = ping_colour(target.marker)
    local sp = spot_of(rec.type)
    target.off = { 0, 0, 0.9 * ((sp and sp.r0) or 1) }
    last_hp = rec.hp
    log(string.format("mark %s entity %d unit %d hp %d / %d marker %s kind %d%s", target.name, m.entity, unit, rec.hp, mx, tostring(target.marker), m.kind or -1, NAMES[rec.type] and "" or (" type " .. rec.type .. " (unnamed)")))
end

-- ------------------------------------------------------------------ drawing --
local ui = { gui = nil, world = nil, text = nil, rect = nil }
local function font_ids()
    local function h(a) local s = rd(a, 8) return s and string.format("%08x%08x", u32(s, 4), u32(s, 0)) end
    local fh, ah = h(game + 0x3772268), h(game + 0x3772ee8)
    local mp = ptr(game + 0x37c5478)
    local mh = mp and h(mp + 24)
    if not fh or fh == "0000000000000000" or not mh or mh == "0000000000000000" or not ah then return nil end
    return fh, mh, ah
end
local function ensure_gui()
    local App, World, Gui, Mat, I = sr.Application, sr.World, sr.Gui, sr.Material, sr.IdString64
    local main, w2 = App.main_world(), nil
    for _, w in ipairs(App.worlds()) do if w ~= main then w2 = w break end end
    if not w2 then return nil end
    local fh, mh, ah = font_ids()
    if not fh then return nil end
    if ui.gui and ui.world == w2 then return fh, mh end
    if ui.gui then                                            -- leave nothing visible on the previous gui
        pcall(Gui.update_text, ui.gui, ui.text, " ", I.from_hex(fh), 18, I.from_hex(mh), sr.Vector3(0, 0, 952), sr.Color(0, 0, 0, 0))
        pcall(Gui.update_rect, ui.gui, ui.rect, sr.Vector3(0, 0, 950), sr.Vector2(0, 0), sr.Color(0, 0, 0, 0))
    end
    ui.gui = World.create_screen_gui(w2, "scale", 1, 1)
    ui.world = w2; ui.text = nil; ui.rect = nil
    local ink = Gui.material(ui.gui, I.from_hex(mh))
    local function slot(x) return I.from_hex(x .. "00000000") end
    for _, x in ipairs({ "8035c266", "5e8455fe", "309e7783", "82b803a8" }) do Mat.set_scalar(ink, slot(x), 0) end
    Mat.set_vector2(ink, slot("e13777ce"), sr.Vector2(1, -1))
    Mat.set_vector4(ink, slot("7701209e"), sr.Color(0, 0, 0, 0))
    Mat.set_texture(ink, slot("88bac99b"), I.from_hex(ah))
    return fh, mh
end
local function draw(line, color, sx, sy)
    local Gui, I = sr.Gui, sr.IdString64
    local fh, mh = ensure_gui()
    if not fh then return end
    local font, mat = I.from_hex(fh), I.from_hex(mh)
    local w, h = Gui.resolution()
    local size = 18
    local tw = 12 * #line
    local okx, ext = pcall(function()
        local lo, hi = Gui.text_extents(ui.gui, line, font, size)
        return sr.Vector3.x(hi) - sr.Vector3.x(lo)
    end)
    if okx and type(ext) == "number" and ext > 0 and ext < w then tw = ext end
    local x, y = math.floor((sx or w / 2) - tw / 2), math.floor((sy or h * 0.40) + OFFSET)
    local rp, rs = sr.Vector3(x - 8, y - 6, 950), sr.Vector2(tw + 16, size + 10)
    local bg = sr.Color(line == " " and 0 or 140, 15, 20, 30)
    if ui.rect then Gui.update_rect(ui.gui, ui.rect, rp, rs, bg) else ui.rect = Gui.rect(ui.gui, rp, rs, bg) end
    local tp = sr.Vector3(x, y, 952)
    local c = sr.Color(color[1], color[2], color[3], color[4])
    if ui.text then Gui.update_text(ui.gui, ui.text, line, font, size, mat, tp, c)
    else ui.text = Gui.text(ui.gui, line, font, size, mat, tp, c) end
end
local cam, cam_t = nil, -1
local function screen_of(now)
    if not target or not target.off then return nil end
    local rx, ry, rz = unit_position(target.unit)
    if not rx then return nil end
    local World, Unit, Camera, V = sr.World, sr.Unit, sr.Camera, sr.Vector3
    local w = sr.Application.main_world()
    if not cam or now - cam_t > 5 then
        cam = nil
        local list = World.units_by_resource(w, "core/units/camera")
        if type(list) == "table" and list[1] then cam = Unit.camera(list[1], 1) end
        cam_t = now
    end
    if not cam then return nil end
    local wp = V(rx + target.off[1], ry + target.off[2], rz + target.off[3])
    local pose = World.debug_camera_pose(w)
    local cp, fwd = sr.Matrix4x4.translation(pose), sr.Matrix4x4.forward(pose)
    if V.dot(wp - cp, fwd) <= 0.5 then return nil end           -- behind the camera
    local sp = Camera.world_to_screen(cam, wp)
    return V.x(sp), V.y(sp)
end
local shown = false
local function hide() if shown then pcall(draw, " ", { 0, 0, 0, 0 }) shown = false end end

local hp_enabled=true
local menu_registered=false
local menu_retry=0
local function set_hp_enabled(value)
    if type(value)~='boolean' then return end
    hp_enabled=value
    if not value then
        hide()
        target=nil; last_hp=nil; last_mark=nil
    end
    state.hp_enabled=value
    log('HP display '..(value and 'ON' or 'OFF'))
end
local function menu_poll()
    if menu_registered or os.clock()<menu_retry then return end
    menu_retry=os.clock()+2
    local menu=rawget(_G,'ModOptionsMenu')
    if type(menu)~='table' or menu.api~=1 or type(menu.register_option)~='function'
        or type(menu.get)~='function' or type(menu.on_change)~='function' then return end
    local id='codex.enemyhp.enabled'
    local ok,why=menu.register_option(id,{type='toggle',mod='敌人 HP',label='显示敌人 HP',default=true,
        description='开启后显示自己红色标记敌人的名称和血量。关闭立即隐藏标签，并暂停读取标记；舰船上也能设置。'})
    if not ok then log('menu refused: '..tostring(why));return end
    set_hp_enabled(menu.get(id))
    menu_registered=menu.on_change(id,set_hp_enabled)==true
    if menu_registered then log('HP menu registered') end
end

-- ------------------------------------------------------------------- update --
local function tick()
    menu_poll()
    if not menu_registered or not hp_enabled then hide(); return end
    state.frames = state.frames + 1
    local now = os.clock()
    -- the game's own marks decide the target (ping ring)
    local okr, er = pcall(ring_step, now)
    if not okr and state.last_ring_error ~= tostring(er) then state.last_ring_error = tostring(er) log("ring error: " .. tostring(er)) end

    -- label
    local menu = false
    pcall(function() menu = sr.Window.show_cursor() == true end)
    if not target or menu then hide() return end
    if now > target.until_t and not target.dead_t then target = nil hide() return end
    if state.frames % 12 == 0 or not last_hp then
        local hu = health_units()
        local rec = hu and hu[target.unit]
        if rec and rec.hp and rec.hp > 0 then last_hp = rec.hp; if target.max and rec.hp > target.max then target.max = rec.hp end
        elseif hu and not target.dead_t then target.dead_t = now; last_hp = 0; target.until_t = now + 1.5 end
    end
    if target.dead_t and now > target.dead_t + 1.5 then target = nil last_hp = nil hide() return end
    local hp = last_hp or 0
    local mx = target.max or hp
    local line, col
    if target.dead_t then line = SHOW_NAME and (target.name .. "  -  killed") or "killed"; col = { 255, 200, 70, 60 }
    else
        local pct = mx > 0 and math.floor(hp * 100 / mx + 0.5) or 0
        line = string.format("%d / %d  (%d%%)", hp, mx, pct)
        if SHOW_NAME then line = target.name .. "  -  " .. line end
        col = target.colour or { 255, 240, 240, 240 }
    end
    local okp, sx, sy = pcall(screen_of, now)
    if not okp then sx = nil if state.last_proj_error ~= tostring(sx) then state.last_proj_error = tostring(sx) end end
    if target.off and not sx then hide() return end                                     -- off screen / behind you
    local wres, hres = sr.Gui.resolution()
    if sx and (sx < 0 or sx > wres or sy < 0 or sy > hres) then hide() return end
    local ok, err = pcall(draw, line, col, sx, sy)
    if ok then shown = true elseif state.last_draw_error ~= tostring(err) then state.last_draw_error = tostring(err) log("draw error: " .. tostring(err)) end
end

-- ------------------------------------------------------------- game build --
-- Every address above belongs to one game build (Steam 25480438: game.dll 2e2c3b7c.., helldivers2.exe f5fee03d..).
-- Their PE headers (timestamp, image size, checksum) identify it; on any other build the mod stays off.
local BUILDS = {
    { game = { 0x6AB3B43F, 0x4744000, 0xECDA6F }, exe = { 0x6AB382E4, 0x39E8000, 0xE48B1D }, name = "25480438" },
}
local function pe_id(base)
    local d = base and rd(base, 0x40); if not d or d:sub(1, 2) ~= "MZ" then return nil end
    local h = rd(base + u32(d, 0x3C), 0x60); if not h or h:sub(1, 4) ~= "PE\0\0" then return nil end
    return { u32(h, 8), u32(h, 24 + 56), u32(h, 24 + 64) }      -- TimeDateStamp, SizeOfImage, CheckSum
end
local function supported_build()
    local g, x = pe_id(game), pe_id(exe)
    if not g or not x then return nil, "module headers unreadable" end
    for _, b in ipairs(BUILDS) do
        if g[1] == b.game[1] and g[2] == b.game[2] and g[3] == b.game[3]
            and x[1] == b.exe[1] and x[2] == b.exe[2] and x[3] == b.exe[3] then return b.name end
    end
    return nil, string.format("game.dll %X/%X/%X, exe %X/%X/%X", g[1], g[2], g[3], x[1], x[2], x[3])
end

local build, why = supported_build()
if not build then
    state.status = "unsupported_build"
    log(REVISION .. ": unsupported game version (" .. tostring(why) .. "). Enemy HP is off until it is updated for this build.")
    return { revision = REVISION, state = state }
end

local original_update = rawget(_G, "update")
if type(original_update) == "function" then
    rawset(_G, "update", function(...)
        local ok, err = pcall(tick)
        if not ok and state.last_error ~= tostring(err) then state.last_error = tostring(err) log("error: " .. tostring(err)) end
        return original_update(...)
    end)
    read_overrides()
    state.status = "hooked"
    log(string.format("Enemy HP %s loaded (game build %s); offset %d px", REVISION, build, OFFSET))
else
    state.status = "no_update"
end
return { revision = REVISION, state = state }