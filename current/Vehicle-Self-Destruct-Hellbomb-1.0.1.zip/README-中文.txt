载具自毁 1.0.1 地狱火配置版
原模组已支持hellbomb配置；坦克默认就是hellbomb，机甲/FRV默认500kg。
本包保持原作者编译脚本，不改触发机制或倒计时。附加配置将五类载具均设为单次hellbomb。
安装：把本ZIP作为mod导入Arsenal（依赖Bingus Shared Loader v15+或原作支持的MDL），停用原版重复包，部署。
额外配置步骤（必须）：解压Configuration/VehicleSelfDestruct.cfg，复制到 %LOCALAPPDATA%\VehicleSelfDestruct.cfg 。
如已存在该配置，先备份；不想覆盖其他设置，可仅将五个explosions_*行改为hellbomb，保留其他配置。
本配置只提供爆炸相关键；原脚本解析逻辑对未填写键使用其默认值。
原始操作：Backspace按住2秒启动，默认倒计时10秒；需坐在载具中。相关文字来自编译脚本常量，未游戏内验证。
首次运行若游戏生成了另一位置的VehicleSelfDestruct.cfg，请修改实际生成的文件中的五个explosions_*键；不要把配置放游戏data目录。
原ZIP只含编译LuaJIT脚本；本版未反编译、未执行编译脚本，未验证具体配置路径或爆炸效果。需要游戏内确认。
没有复制三次爆炸；地狱火会伤及驾驶员及附近单位。
没有同步GitHub。
